/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package COE528_Project;

public class PlatinumMember extends BankAccount {
    
     public void onlinePurchase(int amount){
         if(balance >= amount){
            balance -= amount;
                ErrorFile.display("Successful Platium Tier Purchase.", "Your purchase of" + amount +""
                        + "\nwas successful");
         }
         else
             ErrorFile.display("Error Message", "You do not have the funds to make a puchase of $" + amount);
    }
     public String getTier(){
         return "You are a Platinum Member";
     }
    
}