/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COE528_Project;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

public class Manager {
    
    private String username = "manager";
    private String password = "password";    
   
    public Manager(){
       try{
            File loginInfo = new File(username + ".txt");
            if(loginInfo.createNewFile() == true){
                FileWriter writeToFile = new FileWriter(username + ".txt");
                writeToFile.write(username + "\n");
                writeToFile.write(password);
                writeToFile.close();
            }
        }catch(IOException e){
            System.out.println("IOException occured");
        }
 
    }
    
    public Customer addCustomer(String username, String password){
        return new Customer(username,password);
    }
    
    public void deleteCustomer(Customer custToDelete){
        File file = new File(custToDelete.getUsername() + ".txt");
        if(file.delete())
             ErrorFile.display("Confirmation", "File successfully deleted");
    }
}