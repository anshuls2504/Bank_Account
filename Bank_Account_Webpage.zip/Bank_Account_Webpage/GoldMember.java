/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package COE528_Project;

public class GoldMember extends BankAccount {
    
      public void onlinePurchase(int amount){
          if(balance >= amount + 10){
               balance -= (amount + 10);
         ErrorFile.display("Gold Member Purchase Confirmation", "You have made a purchase of $" + amount +""
                 + "\nand with the additional service charge of $10\nthe total cost is $" + (amount +10));
          }
          else
              ErrorFile.display("Error Message", "You do not have the funds to make a puchase of $" + amount +""
                      + "\nwhich has a total cost of $" + (amount+10));
    }
      public String getTier(){
          return "Gold Member";
      }
    
}