/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package COE528_Project;

public class SilverMemeber extends BankAccount {
    
    public void onlinePurchase(int amount){
        if(balance >= (amount + 20)){
            balance -= (amount + 20);
            ErrorFile.display("Successful Silver Tier Purchase.", "A successful purchase of $" + amount +""
                    + "\nalong with the added price of $20\nmeans the final payment is $" + (amount +20));    
        }
        else
            ErrorFile.display("Error.", "You do not have the funds for this transaction.");
    }
    public String getTier(){
        return "You are a Silver Tier Customer.";
    }
    
}