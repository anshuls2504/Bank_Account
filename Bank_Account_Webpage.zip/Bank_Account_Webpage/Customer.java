package COE528_Project;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

public class Customer {
    
    private String username;
    private String password;
    private BankAccount account;
   
    public Customer(String username, String password){
        try{
            File loginInfo = new File(username + ".txt");
            if(loginInfo.createNewFile() == true){
                System.out.println("User created:" + loginInfo.getName());
                this.username = username;
                this.password = password;
                account = new SilverMemeber();
                FileWriter writeToFile = new FileWriter(username + ".txt");
                writeToFile.write(username + "\n");
                writeToFile.write(password + "\n");
                writeToFile.write(""+100);
                writeToFile.close();
            }
            else if(loginInfo.exists()){
                this.username = username;
                this.password = password;
                account = new SilverMemeber();
            }
            else{
                System.out.println("User already exists");
                return;
            }
        }catch(IOException e){
            System.out.println("IOException occured");
        }
    }
    
    public int getBalance(){
        return account.getBalance();
    }
    public void depositMoney(int amount){
        account.addAmount(amount);
        ErrorFile.display("Deposit", "$" + amount + " has been deposited");
        this.setTier();
    }

    public void withdrawMoney(int amount){
        if(account.getBalance() >= amount){
            account.removeAmount(amount);
             ErrorFile.display("Deposit", "$" + amount + " has been withdrawed"); 
            this.setTier();
        }
        else
             ErrorFile.display("Deposit", "You do not have enough funds to withdraw $" +amount); 
    }
    public void onlinePurchase(int amount){
        if(amount < 50){
            ErrorFile.display("Deposit", "Online purchase must be at least $50"); 
            return; }
        account.onlinePurchase(amount);
        this.setTier();
    }
    
    public void setTier(){
        int balance = account.getBalance();
        
        if(balance < 10000){
            account = new SilverMemeber();
            account.setBalance(balance);
        }
        if(balance >= 10000 && balance < 20000){
            account = new GoldMember();
            account.setBalance(balance);
        }       
        if(balance > 20000){
            account = new PlatinumMember();
            account.setBalance(balance);
        }
            
    }
    
    public String getTier(){
        return account.getTier();
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
}
