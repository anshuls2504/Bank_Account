package COE528_Project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.util.*;
import java.io.File;
import java.io.FileWriter;

public class Bank extends Application {
   
    private static final Manager manager = new Manager();
    private Customer tempCust;    
    private Button button;
    private Scene loginPage, managerPage,customerPage;
    private static final ArrayList<Customer> customers = new ArrayList<Customer>();

    public static void main(String[] args) {
               
         String currentDirectory = System.getProperty("user.dir"); 
         File dir = new File(currentDirectory);
         for(File file : dir.listFiles()){
             if(file.getName().endsWith((".txt"))){
                    try(Scanner readFile = new Scanner(file)){
                        String un = readFile.next();
                        String pw = readFile.next();
                        int balance = Integer.parseInt(readFile.next());
                        customers.add(new Customer(un,pw));
                        for(Customer c : customers){
                            if(c.getUsername().equals(un))
                                c.depositMoney(balance - 100); 
                                c.setTier();
                        }
                    }
                    catch(Exception e3){}  
             }
         }
         
        launch(args);
        
    }

    
    @Override
    public void start(Stage window) throws Exception {
        
        window.setTitle("Bank Login");
        
        Label label1 = new Label("Username");
        Label label2 = new Label("Password");
        
        Label label3 = new Label("Enter a username and password for Customer then click 'Create Customer' ");
        Label label4 = new Label("New Customer's username:");
        Label label5 = new Label("New Customer's password:");
        Label label6 = new Label("\n\n\n");
        Label label7 = new Label("Username of the customer you'd like to delete:");
        Label label8 = new Label("\n\n\n");
        
        Label dLabel = new Label("\n\nEnter amount to deposit:");
        Label wLabel = new Label("\n\nEnter amount to withdraw:");
        Label opLabel = new Label("\n\nPrice of product you wish to buy:");
        Label spaces = new Label("\n\n\n");
        
        TextField depositMoney = new TextField();
        TextField withdrawMoney = new TextField();
        TextField op = new TextField();
         
        Button getBalanceButton = new Button("Check Current Balance");
        Button getCurrentLevel = new Button("Check Current Tier");
        Button doDepositAction = new Button("Deposit");
        Button doWithdrawAction = new Button("Withdraw");
        Button doOnlinePurchase = new Button("Checkout");
        Button userLogout = new Button("Logout");
        
        TextField username = new TextField();
        TextField password = new TextField();
        button = new Button("Login");
        
        Button createCustomer = new Button("Create Customer");
        Button deleteCustomer = new Button("Delete Customer");
        Button managerLogout = new Button("Logout");
        TextField createUsername = new TextField();
        TextField createPassword = new TextField();
        TextField userToDelete = new TextField();
        
        button.setOnAction(e ->{ 
               String inputtedFileName = username.getText();
               String inputtedPassword = password.getText();
               File f = new File(inputtedFileName + ".txt");
               if(f.exists()) { 
                    try(Scanner readFile = new Scanner(f)){
                         String usernameOnFile = readFile.next();
                         String passwordOnFile = readFile.next();                     
                     
                    if(inputtedFileName.equals(usernameOnFile) && inputtedPassword.equals(passwordOnFile)){
                        if(usernameOnFile.equals("manager")){
                            window.setScene(managerPage);
                            username.clear();
                            password.clear();
                        }
                        
                        
                        else {
                           for(int i = 0; i < customers.size(); i++){    
                                  if(customers.get(i).getUsername().equals(inputtedFileName)){
                                      tempCust = customers.get(i);
                                  }                        
                           }
                                      window.setScene(customerPage);
                                      username.clear();
                                      password.clear();
                          

                        }
                    }
                    else
                        ErrorFile.display("Error", "Invalid login credentials!");
               
                    }  
                    catch(Exception e1){
                         System.out.println("Something went wrong");
                        }            
               }
               
               else{
                   ErrorFile.display("Error", "User does not exist!");
                           
               }                              
        }
        );
        
        managerLogout.setOnAction(e -> {
          
            window.setScene(loginPage);
            createUsername.clear();
            createPassword.clear();
            userToDelete.clear();
         
        } );
        
        
        userLogout.setOnAction(e -> {
                        try{
                FileWriter writeToFile = new FileWriter(tempCust.getUsername() + ".txt");
                writeToFile.write(tempCust.getUsername() + "\n");
                writeToFile.write(tempCust.getPassword() + "\n");
                writeToFile.write(""+tempCust.getBalance());
                writeToFile.close();
            }
            catch(Exception w){}
            
            window.setScene(loginPage);
            depositMoney.clear();
            withdrawMoney.clear();
            op.clear(); 
                });
        
        createCustomer.setOnAction(e -> {
                customers.add(new Customer(createUsername.getText(),createPassword.getText()));
                createUsername.clear();
                createPassword.clear();
                ErrorFile.display("New Customer", "Customer has been created!");
                });
        
        deleteCustomer.setOnAction(e -> {
           String deleteThisUsername = userToDelete.getText();
           for(int i = 0; i < customers.size() ; i++){
               if(customers.get(i).getUsername().equals(deleteThisUsername)){
                   manager.deleteCustomer(customers.get(i));
                   customers.remove(i);
                   userToDelete.clear();
                   break;
               }
           }          
        });
        
        getBalanceButton.setOnAction(e ->{
            ErrorFile.display("Balance", "Balance is $" +tempCust.getBalance());
        });
        
        
        getCurrentLevel.setOnAction(e -> {
            ErrorFile.display("Balance", tempCust.getTier());
        });
       
        doDepositAction.setOnAction(e ->{
            try{
                int amount = Integer.parseInt(depositMoney.getText());
                tempCust.depositMoney(amount);
                depositMoney.clear();
            }
            catch(NumberFormatException e1){
                     ErrorFile.display("Error", "An integer must be entered!");  
                     depositMoney.clear();
            }      
        });
        
        doWithdrawAction.setOnAction(e -> {
            try{
                int amount = Integer.parseInt(withdrawMoney.getText());
                tempCust.withdrawMoney(amount);
                withdrawMoney.clear();
            }
            catch(NumberFormatException e1){
                     ErrorFile.display("Error", "An integer must be entered!");  
                     withdrawMoney.clear();
            }      
        });
        
        doOnlinePurchase.setOnAction(e -> {
             try{
                int amount = Integer.parseInt(op.getText());
                tempCust.onlinePurchase(amount);
                op.clear();
            }
            catch(NumberFormatException e1){
                     ErrorFile.display("Error", "An integer must be entered!");
                     op.clear();
            }  
        }
        );            
        VBox layout1 = new VBox(10);
        layout1.setPadding(new Insets(20,20,20,20));
        layout1.getChildren().addAll(label1,username,label2,password,button);
        
        loginPage = new Scene(layout1,600,200);
       
        VBox layout2 = new VBox(10);
        layout2.setPadding(new Insets(20,20,20,20));
        layout2.getChildren().addAll(label3,label4,createUsername,label5,createPassword,createCustomer,label6,label7,userToDelete,deleteCustomer,label8,managerLogout);
        
        managerPage = new Scene(layout2,600,450);
        
        VBox layout3 = new VBox(10);
        layout3.setPadding(new Insets(20,20,20,20));
        layout3.getChildren().addAll(getBalanceButton,getCurrentLevel,dLabel,depositMoney,doDepositAction,wLabel,withdrawMoney,doWithdrawAction,opLabel,op,doOnlinePurchase,spaces,userLogout);
        
        customerPage = new Scene(layout3,1000,500);
        
        window.setScene(loginPage);
        window.show(); 
    }
}