package COE528_Project;
// This class is mutable, as the balance or account levels can both change.
// Abstraction function: new balance will be = current balance.
// Rep Invariant: Checks if current balance is greater than 0. If yes, returns true.
public abstract class BankAccount {
    
    // Rep Invariant
    protected int balance;
    
    // Requires: An active bank account.
    // Modifies: Default account balance is initiated at $100.
    // Effects: Account balance is now $100.
    public BankAccount(){
        balance = 100;
    }
    // Requires: Balance.
    // Modifies: N/A
    // Effects: Returns balance.
    protected int getBalance(){
        return balance;
    }
    
    // Requires: A balance to be greater than 0.
    // Modifies: Sets the new balance amount if the newly implimented balance is greater than 0.
    // Effects: Changes old balance to new one.
    protected void setBalance(int newBalance){
        if(newBalance >= 0)
            this.balance = newBalance;
    }
    
    // Requires: An amount to deposit to be greater than 0.
    // Modifies: The balance by adding the new deposited amount.
    // Effects: Adds the deposited amount if it is greater than or equal to 0.
    protected void addAmount(int amount){
        balance += amount;
    }
    // Requires: An amount to be withdrawn which will be less than their current balance.
    // Modifies: The balance by removing the amount requested to be withdrawn.
    // Effects: Removes the amount requested.
    protected void removeAmount(int amount){
            balance -= amount;
    }
    
    // Requires: The purchase amount to be greater than $50.
    // Modifies: Balance by whatever amount the purchase was.
    // Effects: Item is purchased and balance is withdrawn accordingly.
    public void onlinePurchase(int amount){} 
    
    // Modifies: N/A
    // Effects: Returns Tier of Customer.
    public  String getTier(){return "String in abstract";}
    
    // Modifies: N/A
    // Effects: Returns balance
    @Override
    public String toString(){
        return "Balance is $" + balance;
    }
    // Requires: The balance to be greater than 0.
    // Modifies: N/A
    // Effects: Returns true if the balance is greater than 0, if not then it's false.
    public boolean RepOK(){
        if(this.balance > 0)
            return true;
        return false;
    }
    
}
